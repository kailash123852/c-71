import firebase from "firebase";


//Paste your firebaseConfig here
const firebaseConfig = {
  apiKey: "AIzaSyCLEvrfkbxWD2grD6w66o8b056vQIBKCq4",
  authDomain: "c-71-c7d6f.firebaseapp.com",
  projectId: "c-71-c7d6f",
  storageBucket: "c-71-c7d6f.appspot.com",
  messagingSenderId: "381689737790",
  appId: "1:381689737790:web:081abbca959c786db0176f"
};
//
firebase.initializeApp(firebaseConfig);

export default firebase.firestore();
